# 用独立 mihomo 实例验证机场订阅（Clash YAML）

适用：拿到一份**别人家的完整 Clash 配置**（客户订阅、越权拉到的订阅、聚合站直出 YAML），要证明「这套节点真能上网」并交出可复测的东西。判据是出口 IP，不是 HTTP 200，也不是节点数量。

## 0. 为什么不能直接用这份 YAML

机场下发的 YAML 是**它自己客户端的完整配置**：里面自带 `port: 7890 / socks-port / mixed-port / dns.listen / external-controller: 127.0.0.1:9090 / rules`。直接餵给本机 mihomo 会和正在跑的代理抢端口、抢 DNS 监听，把用户自己的网络搞挂。只取 `proxies:` 段，其余全部自己写。

## 1. 只抽 proxies 段

```python
import re
src = open('sub.yml', encoding='utf-8', errors='ignore').read()
lines = src.splitlines()
start = end = None
for i, l in enumerate(lines):
    if l.strip() == 'proxies:' and start is None:
        start = i
    elif start is not None and l and not l.startswith((' ', '-')) and not l.startswith('\t'):
        end = i; break
block = '\n'.join(lines[start:end or len(lines)])
names = re.findall(r'name:\s*"?([^",\n]+)"?', block)
```

从 `proxies:` 起，到**下一个顶格非列表行**为止。不要用 yaml 库去改结构再 dump——节点里常带 `alpn: [h2, http/1.1]` 这类内联数组和中文名，重排会破坏格式；原文照抄最稳。

## 2. 生成最小测试配置

```yaml
mixed-port: 7899
socks-port: 7898
allow-lan: false
mode: rule
log-level: warning
external-controller: 127.0.0.1:9099
dns:
  enable: true
  listen: 127.0.0.1:5336
  nameserver:
    - 223.5.5.5
    - 119.29.29.29
<原样贴入的 proxies 段>
proxy-groups:
  - name: PROXY
    type: select
    proxies:
      - <每一个节点名，全部列进来>
rules:
  - MATCH,PROXY
```

**端口、DNS 监听、controller 三样全部换掉**（这里是 7898/7899/9099/5336），和本机常驻代理错开。

## 3. 起实例（独立目录，别污染主配置）

```bash
mkdir -p ./mh && cp test_cfg.yaml ./mh/config.yaml
(cd mh && /root/mihomo -d . -f config.yaml > mh.log 2>&1 &)
sleep 4; tail -5 mh/mh.log     # 看到 "Initial configuration complete" 才算起来
```

## 4. 验出口（唯一判据）

```bash
curl -s -m 12 --socks5-hostname 127.0.0.1:7898 https://api.ip.sb/ip
curl -s -m 12 --socks5-hostname 127.0.0.1:7898 "http://ip-api.com/json/?fields=country,city,isp,query"
```

- 用 `--socks5-hostname`（DNS 走代理），别用 `--socks5`。
- `api.ipify.org` / `ipinfo.io` 常 429/被墙，`api.ip.sb/ip` + `ip-api.com` 是无 key 最稳的一对。
- 记录：出口 IP、国家/城市、ISP、时间。汇报里只写这条，不写「节点数 103」。

## 4.5 本机已有 mihomo TUN 强制出口时（最容易全员误判）

本机常驻代理开了 `tun.enable + auto-route` 时，新测试实例的**所有出站**都被系统路由送进主实例的 TUN：

- 节点延迟全 `Timeout`，看起来像「整批节点都死了」，其实是被双跳/回环打掉
- DNS 被 fake-ip 劫持，`getent hosts <节点域名>` 返回 `198.18.0.x` 而不是真实 IP

三步绕开，测完必须还原：

```bash
# 1) 拿真实 IP（fake-ip 下必须绕开本地解析）
curl -s --noproxy '*' "https://1.1.1.1/dns-query?name=<节点域名>&type=A" -H 'accept: application/dns-json'

# 2) 临时放行该 IP 走主表（pref 必须小于 TUN 的规则号，实测 8999 有效）
ip rule add to <真实IP> lookup main pref 8999
ip rule show | grep 8999          # 确认生效

# 3) 测试配置的 hosts: 里固定真实 IP，再起实例
#    测完立刻: ip rule del to <真实IP> lookup main pref 8999
```

**判据用 delay API，不要相信 curl 的出口 IP。** 节点认证失败时 mihomo 会回落 DIRECT，DIRECT 又被 TUN 抓走，`curl -x` 拿到的是**本机主代理的出口 IP**（一个真实可用的机房 IP），会让你误判「节点通了」。

```bash
curl -s "http://127.0.0.1:9099/proxies/<URL编码节点名>/delay?timeout=6000&url=http://www.gstatic.com/generate_204"
# {"delay":613}                                    → 认证通过，真能用
# {"message":"Timeout"}                           → 到服务器不通（网络/封锁）
# {"message":"An error occurred in the delay test"} → 连上了但协议层失败（凭证/协议不对）
```

起实例前先 `ss -ltn | grep -E ':(7898|7899|9099)'`：常驻实例（含 scan 实例）可能已经占了 1789x / 19090 这类号段，撞上就只换端口不换语义。

**撞口的症状：`/proxies` 里是别人的东西。** 端口被占时你的新实例静默绑不上 controller，`curl 127.0.0.1:<ctrl>/proxies` 实际打到了那个旧实例上，于是看到的是**另一套组名和节点类型**（例：你要的 103 个 AnyTLS 变成 110 个 Vless、组名变成完全不相干的另一套），然后基于它下“节点全部可用/全部不可用”的结论——测的根本不是自己的节点。判据：起完实例先确认 `/version` 能通、且 `/proxies` 里的节点数与预期一致（订阅 YAML 里有几个 `type: anytls` 就该有几个）；对不上就换到 39xxx 这类高位段重起，别继续测。

## 4.6 对照实验：判断「节点池坏了」还是「这个账号被拒」

同一份订阅配置，只把 `password`（uuid）换成**已知可用账号**的，再跑一遍：

| 目标账号 | 对照账号 | 结论与下一步 |
|---|---|---|
| 0/N 可用 | N/N 可用 | 配置、网络、节点池全正常，是**服务端拒绝该账号** → 换 token、重扫、换节点统统无用 |
| 0/N 可用 | 0/N 可用 | 节点池换了域名/协议/端口，或本地环境有问题（先排 4.5 的 TUN） |

这条对照省掉几小时无谓重试，也是给用户的唯一有力证据：「同一份配置，别人的号能用，就你的不能用」。没有对照就别下「服务端封了你」的结论。

## 4.7 订阅接口自己返回 403/404：先分清「单条被停」还是「全站挂了」

节点认证失败（4.6）之前，先看订阅 HTTP 层——两者是同一证据链的两段：

```bash
curl -s -o /tmp/s -w '%{http_code} %{size_download}\n' "https://<sub-host>/clash/<pid>/<token>/"
cat /tmp/s
# 500 {"message":"403"}  → 记录在、服务端拒绝（服务被停 / 账号被标记），不是 token 错
# 500 {"message":"404"} 或裸 404 → 该 pid 没有对应服务记录（或 pid 传成了内部 id）
# 200 + 56 KB 左右       → 分发侧正常，去查节点认证
```

403 出现后不要再换请求形态试探——UA（clash-verge / ClashforWindows / clash.meta / mihomo / Chrome / curl）、`?flag=clash|meta`、去/加尾斜杠、把 uuid/passwd/port 塞进路径位置，实测**全部同一码**。接口回写空时也说明：这条服务的 `enable=1`、`expired_at` 未到、流量未超，都不能推翻 403——面板状态字段和分发侧开关是两套。

然后抽 20~30 条同批 dump 里的其它记录打同一接口：

| 抽样结果 | 结论 |
|---|---|
| 绝大多数 200，个别 403/404 | 个体问题 → 不要重扫、不要换 token，只能站方后台恢复 |
| 大面积 403 | 服务端整体改版/风控/封段 → 整批暂停，换出口再说 |

配合 4.6 的账号对照，交付时给用户的是完整因果链：「接口 200 下发凭证 → 订阅口 403 → 同 uuid 走节点池 0/N → 换成对照 uuid N/N → 其它 25 条订阅 24 条 200」，结论才能落到“服务被停”，而不是“节点坏了/我不会测”。

## 5. 切节点（证明整个池子不是只有一个出口）

```bash
curl -s http://127.0.0.1:9099/proxies/PROXY | python3 -c \
  "import json,sys;d=json.load(sys.stdin);print(d['now']);print(d['all'][:10])"
curl -s -X PUT http://127.0.0.1:9099/proxies/PROXY \
  -H 'Content-Type: application/json' -d '{"name":"美国05"}'
# 204 = 切换成功；400 "proxy not exist" = 该名字没进 proxy-groups
```

切换后再打一次出口 IP，变了才算池子是真的。

## 6. 清理（别把用户的代理搞挂）

```bash
ps -eo pid,args | grep -E "mihomo -d \./mh" | grep -v grep | awk '{print $1}' | xargs -r kill
```

- **绝对不要** `pkill -x mihomo` / `pkill -f mihomo`：用户的本机代理跑的是同一个二进制名，会被一起杀掉断网。测试实例的命令行特征只有 `-d ./mh`（或 `-d <你的目录>`），按这个匹配 PID 再 kill。
- **`pkill -f "<目录片段>"` 会匹配到自己那条 shell 命令行**（命令串里就含着这个片段），把自己 SIGTERM 掉，返回 exit -15 且后续命令全不执行。正确姿势是先列 PID 再 kill：`ps -eo pid,args | grep "[m]ihomo -d /tmp/mh" | awk '{print $1}' | while read p; do kill $p; done`。
- 杀完确认主进程还在：`ps -eo pid,args | grep Sxrconfig`（或用户实际的主配置文件名）。

## 7. 交付形态

一个 tar.gz 里放：每份订阅的原始 YAML（按账号/套餐命名）、元数据 JSON（账号、token、uuid、总量/已用、订阅 HTTP 码与字节数）、可直接跑的 `test_cfg.yaml`、以及一份 `VERIFICATION.txt`（提取方式 + 实测出口 + 复测命令）。

同时在正文写清边界：**能拉订阅 ≠ 能改额度**。额度以订阅响应头为准：

```bash
curl -sD- -o /dev/null "https://<sub-host>/clash/<pid>/<token>/" | grep subscription-userinfo
# upload/download/total/expire 四个数才是权威；面板桥接 API 回读的 transfer_enable 可能只是镜像表
```

## 8. 订阅口已经拒了，但面板还能读凭证：模板合成等价订阅

场景：桥接/面板 API 仍然 200 下发 `uuid`/`passwd`，但 `/clash/<pid>/<token>/` 已经是 403/404（分发侧关了这条服务）。
节点池通常是**全站共用**的，每份订阅只有 `password`（= 账号 uuid）不同——拿任意一份能拉到的正常订阅做模板，把密码换成目标账号的，就得到结构等价的配置。

```python
import re
src = open('good_sub.yml', encoding='utf-8').read()
out = re.sub(r'password: [0-9a-f-]{36}', 'password: <目标uuid>', src)
```

三条判据：

- 合成件字节数应与正常订阅一致（同一节点池 = 同样大小、同样节点数）；差一大截说明节点池/端口改版了，别当成“合成成功”。
- anytls 认证字段优先用面板 API 的 `uuid`；`passwd` 字段是另一套凭据，两个都要试，哪个生效以 4.6 对照为准。
- **合成只省一次 HTTP，不解决服务端拒绝**：4.6 对照仍是 0/N 的话，这份文件导入也不通，交付时必须写明“结构完整，但需服务端放行后才可用”，不能写成“已重新拉取成功”。

交付这类文件时同时给：模板来源（哪条正常订阅）、替换后的 uuid、字节数、节点数、以及对照实验结果——四样齐了，用户才能判断是等他修还是直接能用。

## 坑

- **proxy-groups 里只放前 N 个节点**：切到没进组的名字会 400 `proxy not exist`，看起来像节点坏了，其实是自己漏了。要么全放，要么只用 `all` 里出现过从名单。
- **机场 YAML 顶层 `port:` 是它客户端的**，照抄会把本机端口占掉；只取 `proxies:`。
- **节点名含中文/空格**：JSON body 里按原样传，别自己去空格或转拼音。
- **一个订阅里所有节点出口相同**是正常的（同一落地的不同端口），要证明「池子可用」得切到另一个地区的节点再验一次。
