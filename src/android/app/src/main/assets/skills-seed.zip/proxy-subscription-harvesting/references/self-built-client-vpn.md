# 自研客户端型机场（无 Clash/vless 订阅链接）

有一类机场不发标准订阅：官网只给客户端下载（Flutter APK / Go CLI），节点配置由 `/system/initconfig` 之类的接口**加密下发**。`proxy-subscription-harvesting` 主文档里的「抓订阅 URL」整条链在这里不适用，走下面这套。

识别特征：

- 站点首页只有 download 页，没有 `/api/v1/client/subscribe?token=`
- 前端 JS 里 grep 不到 `vless://` / `proxies:`
- 有 `/system/initconfig`、`/system/clientnodelist`、`/system/clientnodelist_v3` 这类接口
- APK 解包是 Flutter（`libapp.so` 是 Dart AOT）+ Go native 库（`libgojni.so` / `libtunnel-core.so` / `libtun2sockslib.so`）

## 1. 未鉴权拿配置

```bash
curl "https://<api>/system/initconfig?platform=android&cur_version=0.0.0&lang=en&code=Others"
# → {"code":0,"data":{"sys_proxy_file":"http://<cfg-host>/domain_others_proxy.txt",
#                    "sys_local_file":"http://<cfg-host>/domain_others_local.txt"}}
```

这两个 txt 和 `clientnodelist_v3` 都是 **urlsafe base64 → AES-256-CBC**：

```python
raw = base64.urlsafe_b64decode(s + '=' * (-len(s) % 4))
```

## 2. 挖硬编码密钥（Go 客户端未去符号时最快）

客户端本体从官网/assets 域名直接下（常见 `https://assets.<domain>/others/linux/<Client>-x86_64-unknown-linux-gnu`），几十 MB、带完整 symtab：

```bash
nm vtc | grep -i AESDecrypt                  # → privatesscorepc/global.AESDecrypt
objdump -d --start-address=0x<init> vtc | head -80
# 找 init 里的填充循环：
#   cmp $0x20,%rdx / movb $0x31,-0x1(%rbx,%rax,1)   → 32 字节 0x31 = AES_KEY
#   cmp $0x10,%rdx / movb $0x31,-0x1(%rbx,%rax,1)   → 16 字节 0x31 = AES_IV
```

**key/iv 都是同一个字节**（开发者偷懒写死 `'1'*32` / `'1'*16`）是很常见的形态——看到 init 里 movb 立即数进循环就不用去追字符串常量了。

解：

```bash
openssl enc -d -aes-256-cbc -K $(python3 -c "print('31'*32)") -iv $(python3 -c "print('31'*16)") -in ct.bin
```

解出来是**分流规则**（域名/IP 正则表）或**节点 JSON**，不是密码。规则表本身有价值：里面会露出客户端还会连的其它域名（配置主机、metrics 主机、老版本 API）。

## 3. 节点 JSON 里有啥、以及它故意不给啥

```json
{"nodes":[{"uuid":"...","name":"Hong Kong-5000M No.131","ip":"103.85.75.131",
  "port":"15889","method_type":"default","udp":true,
  "http_path":"/api/v1/android/ping","http_user_agents":"Mozilla/5.0 (Linux; Android 14)...",
  "relay":[{"uuid":"...","ip":"112.65.199.134","name":"Hong Kong-CU-No.131"}]}]}
```

- `ip` 常常是**云 CDN 前端**（响应头带 `Eagleid` / `X-Swift-Cachetime` = 阿里云全站加速），真节点在 `relay[]` 里（国内联通/电信中转 IP）
- **没有 password 字段**。不要指望在这里拿到 SS 凭据

## 4. 登录：密码几乎总是 md5，不是明文

自研后端的登录体常见 `{email, password}`，前端会调一个压缩后的 `tm(pw).toString()`——grep 不到 RSA/AES/JSEncrypt 痕迹就说明**不是加密，是哈希**。按这个顺序试，一条一条来（429 时换出口，见 `egress-ip-rotation`）：

```
明文 → md5(pw) → sha256(pw) → base64(pw)
```

实测 md5 命中率最高。失败报 `Verification failed. Please check your input or try again later.`（不区分邮箱不存在，防枚举）。

## 5. token 传参形态必须三种都试

同一个接口，token 放错位置会报「参数错误」而不是「未授权」，很容易误判成接口不通：

| 形态 | 结果 |
|---|---|
| `?token=<TOK>` query | ✅ 通 |
| `Authorization: Bearer <TOK>` | ❌ `Failure: Failure: Parameter error` |

先试 query。拿到 token 后先打 `<api>/appuser/userinfo` 确认身份和档位（`charge_type` 0=免费、`transfer` 剩余流量、`charge_expire_date`）。

## 6. 两个必踩的假信号

**`socks5_addr` 是「每账号每节点」的一条记录，不是节点凭据的容器。** `GET /appuser/node-socks5?uuid=X` 返回 `{"email":<你的邮箱>,"node_uuid":...,"socks5_addr":"","updated_at":0}`——响应里带 `email` 说明它是 per-user 的；前端里同一路径还有 `POST {uuid, socks5_addr}` 语义，**写的是客户端上报的本地监听地址**，不是服务端下发节点密码的通道。

所以 `socks5_addr` 空只证明「这个账号在这个节点上没有记录」（`updated_at: 0` = 从没写过），**不能外推成「这个字段永远不装凭据」**。档位边界用 §7 的三个信号判（`charge_type` / `personal-node-list` / `private-node-relay`），不要用这个字段判。免费档实测空串；付费档是否非空是**未验证项**——要验就换付费账号把这一串重打一遍，别在免费账号上反复试。

**节点密码不是 uuid 派生出来的。** 实测 md5/sha1/sha256(前32)/b32/b64 × uuid(带/不带横线)/明文密码/md5密码/邮箱/IP/端口 的全组合，对真实密码零命中。密码是服务端按节点独立存的随机串（32 位 base62）。

## 7. 免费档到哪为止

以下三个信号同时出现，就说明这条路在服务端封死了，收工写报告，别再啃：

- `userinfo.charge_type == 0` 且 `chargehistory == []`（免费档，无购买记录）
- `personal-node-list == []`
- `POST /appuser/private-node-relay {uuid, relay}` → `Private node not found`

此时 `public-node-socks5-list` 仍会返回 20-40 条节点 uuid，但都不带密码——免费档只给「看得见节点名」，不给「连得上」。

## 8. 客户端自动化：别用 stdin 管道

Go + bubbletea 写的 TUI 客户端（`Input email:` → `Input password:`）**不接受管道字节流**：

- 管道喂入后第二行会直接回显在终端，卡在 `Input email:` 不动（`expect` 用 `exp_continue` 匹配 prompt 会因重绘无限循环，把日志刷到几百 MB）
- 需要真实键盘事件，靠 tmux `send-keys` 之类的真 PTY

**先看它自己的配置目录再决定要不要跑它**：

```bash
ls -la ~/.config/<Client>/
#   config.ini   ← 全部值是 AES 加密的（同一把 key），含 web/api 地址
#   server.log   ← 明文日志，能看到它在探测哪些 relay:port、用了什么 profile
```

```bash
strace -f -e trace=network,openat -s 300 -o st.log timeout 25 ./Client
# 直接看到：它连哪个 API:port、读哪个 config、本地监听哪个端口
```

config.ini 用同一把 AES key 解（urlsafe base64），能解出 `web=https://web.<domain>`、`api=<后端地址>`。

## 9. 这类站点的高发伴生洞（比拿节点更容易出活）

客户端型机场的更新/引导链路普遍薄弱，值得单独立项：

- **install.sh 供应链**：`curl -kLf`（关 TLS 校验）+ 只 `dd` 取前 4 字节比对 `\177ELF` 魔数 + 无哈希签名 → MITM 换任意 ELF 落 `/usr/local/bin/`，root 执行
- **配置下发 MITM**：`sys_proxy_file` 走明文 HTTP + 共享硬编码 key → 改 hosts 指向本地即可让客户端连上来，抓到明文登录体（用户密码 md5）
- **未鉴权接口群**：`/system/*` 命名空间（initconfig/clientnodelist/checkupdate）通常不校验；`/appuser/tokendel` 一类只校验「token 非空」不校验归属

这三条的证据形态：`curl` 原始响应、篡改后的 tamper.log、自编译 PoC 二进制的运行输出。

## 10. 上传点：先判落地，再决定要不要试 webshell

工单/头像上传普遍直传对象存储。判据是响应体三件套，不用猜：

```json
{"code":0,"data":{"name":"a.png","url":"","key":"support-tickets/2026/10/<id>/<ts>-a.png",
  "content_type":"application/octet-stream","provider":"cloudflare"}}
```

`provider` 有值（cloudflare/r2/s3/oss）+ `url` 空 + `key` 是对象键 → **文件不在 Web 根、没有任何解释器会执行它**。实测这条路上：

- 传 txt 直接回「附件仅支持图片或视频，文件格式与内容必须一致」（魔数校验）
- 名字穿越只取 basename：`../../../others/linux/x.png` → `support-tickets/.../x.png`
- 所以既没有 webshell，也覆盖不到 assets 上的客户端二进制

**结论：这类站点没有服务端 RCE 入口。**真正的高危在客户端更新链（§9），但那需要 MITM 或打掉 assets 源站——assets 前挂 CF 时看 `cf-cache-status`：`DYNAMIC` 表示每次都回源，仍然要求你找到源站；拿不到源站就不存在「无需 MITM 的通杀 RCE」。报告里必须写清这个前提，**不能把客户端侧供应链 RCE 写成服务端 RCE**。

### 想从 assets 侧投毒：先判它是 CF Pages 还是回源站点（省一整轮）

打 assets 之前花两分钟判型，判错会白跑一轮子域扫描 + passive DNS：

```bash
# 1) 请求一个不存在的路径，看 404 页是谁的画风
curl -s https://assets.<domain>/__nonexistent__ | head -20
#   CF Pages 默认 404：<title>Not Found</title> + <link rel="icon" href="https://www.cloudflare.com/favicon.ico">
# 2) CF Pages 的部署标记文件
curl -s -o /dev/null -w '%{http_code}\n' https://assets.<domain>/_headers    # 404 = 没走标准 Pages 部署或没配
curl -s -o /dev/null -w '%{http_code}\n' https://assets.<domain>/_redirects
```

- **404 页是 CF Pages 默认页 → 静态托管，没有源站服务器可打。** 文件只能通过 Cloudflare 部署凭据（API token / 关联 Git 仓库）更新；拿不到凭据就只剩 MITM 一条路，报告按「客户端 MITM 链」定性。
- 此时 `cf-cache-status: DYNAMIC` **不能**当成「有源站可挖」的证据——Pages 的 Functions/Worker 也是 DYNAMIC。
- 顺手试 `*.pages.dev` 预览域（`<project>.pages.dev`）：命中说明有独立预览环境，常有未加固的构建产物。
- 判对象存储是否可列：`?list-type=2` 返 404 = 不可列，别继续猜前缀试目录。

### passive DNS 能挖到什么、挖不到什么

两条免费无鉴权的（比 crt.sh 稳，crt.sh 经常超时返空）：

```bash
curl -s "https://api.hackertarget.com/hostsearch/?q=<domain>"
curl -s "https://api.certspotter.com/v1/issuances?domain=<domain>&include_subdomains=true&expand=dns_names"
```

- 返回的是**历史 A 记录**，会给出当前 DNS 已不再解析的老 IP——这是它唯一的价值。
- **挖出来的裸 IP 大概率是节点机/中转机，不是 Web 源站**：判据是只开 22/SSH、80/443 全关。这类机器对「改 assets 文件」没用，别在上面耗（SSH 弱口令也不值得为这个目标去试）。
- hackertarget 免费额度按请求计数，跑十几个查询就 `API count exceeded`，先把字典定好再批量打。
- 子域全量扫一遍全是 CF 时，就不要再指望「找个漏网的裸源站」——这类团队把 CF 当标配，源站只在防火墙后。

顺带一条省时的：注入探测前先确认参数真的进了 SQL——同一个接口不带参数和带 `'` 返回字节完全相同，就是参数被忽略（或全程参数化），别在这上面耗 sqlmap。

## 11. `internal.*` 子域：同一后端只多挂一套 admin 路由

拿到 API 域名后，扫子域时**专门盯 `internal.` / `manage.` / `panel.` 这种名字**——它们常 CNAME 到 `internal.<另一个自有域>`，而且**和公网 API 是同一套后端**，不是独立系统：

```bash
# 判据：同样的接口在 internal 上原样能通，说明同库同进程
curl -s "https://internal.<domain>/system/clientnodelist_v3?platform=web&..."   # 200 密文
curl -s "https://internal.<domain>/appuser/userinfo?token=<TOK>&..."            # 200 自己账号
```

确认同后端后，用管理路由字典扫（`/admin/users`、`/admin/nodes`、`/admin/tickets` …）。**存在的返 200 + `{"code":7,"msg":"管理员登录已失效，请重新登录"}`，其余 404**——这个差异就是「接口存在但需管理员态」的铁证，可单独记一条 finding。

两个后续判断：

- 响应头会泄露鉴权设计：`access-control-allow-headers: Content-Type,AccessToken,X-CSRF-Token,Authorization,Token` → 鉴权走 `AccessToken` 头而不是 Bearer；同时 `allow-origin: *` 配 `allow-credentials` 是无效组合，说明 CORS 配得粗糙。
- **管理登录口通常不在这台域名上**（`/admin/login` `/admin/auth` `/admin/signin` GET/POST 全 404），大概率 IP 白名单或独立域名。没登录口就别在 admin 接口上死磕口令，转去挖客户端链或换目标。

## 12. 拿到密码之后：`ss://` 重建、`#vt` 后缀、以及「标准客户端连不上」的三种解释

密码不会从接口下发给你看（见 §6），但一旦从用户/付费账号/客服手里拿到一串，剩下的全是容易反复栽的坑。本节是本类目标投入产出比最高的一段。

### 12.1 `#` 既是 URL 片段分隔符，也可能就是密码的一部分

`ss://` 的形态是 `ss://<base64(method:password)>@<host>:<port>#<备注名>`。看着 `#` 后面就是 tag，于是很自然写成：

```python
method, _, rest = dec.partition(':')
pw, tag = rest.split('#', 1)        # ← 这一步把真密码截断
```

实测密码形如 `<32位base62>#vt`，**`#vt` 是密码后缀，不是备注**。正确解法：

```python
userinfo = base64.urlsafe_b64decode(s + '=' * (-len(s) % 4)).decode()
method, _, password = userinfo.partition(':')      # password 保留 '#vt'
```

自检：按错法解出来的密码配到客户端后是「TCP 通、握手死」，而且长度和真密码差一截。所以拿到任何 `ss://` 先 `print(base64 解出来那一串)` 人眼看一眼有没有可疑的 `#xxx` 尾巴，别直接信自己的 split。

### 12.2 后缀贴在 password 上，不能贴 cipher 上

魔改 mihomo 的实现是 **cipher 层的 wrapper**（见 12.3），但**配置层只认「贴在 password 上」这一种写法**：

```yaml
# ✅ 对
cipher: chacha20-ietf-poly1305
password: "<32位base62>#vt"

# ❌ 错，mihomo 直接启动失败
cipher: chacha20-ietf-poly1305#vt
# level=fatal msg="... unknown method: chacha20-ietf-poly1305#vt"
```

### 12.3 标准客户端连不上 ≠ 凭据错：这类协议是服务端定制的

stock sing-box、原版 mihomo、任何通用 SS 客户端都不够用。先确认手里的二进制是不是对的那个：

```bash
strings <mihomo 二进制> | grep -iE 'viewturbo|viewTurboMethodWrapper|wrapViewTurboConn'
# → sing-shadowsocks2/cipher.(*viewTurboMethodWrapper).DialConn
#   sing-shadowsocks2/cipher.wrapViewTurboConn
#   sing-shadowsocks2/cipher.(*viewTurboConn).Read / .Write
```

**用目标自己的客户端二进制**（用户机器上那个魔改 mihomo），别自己攒：

```bash
mkdir -p /root/<inst> && cp config.yaml /root/<inst>/
/root/mihomo -d /root/<inst> -f /root/<inst>/config.yaml     # 独立实例，独立端口
```

- 独立实例必须改 `mixed-port` 和 `external-controller`，否则和主实例抢端口报 `bind: address already in use`。
- 清进程用精确 PID：`pgrep -f '<inst 目录名>'` → `kill -TERM <pid>`。
- **`pkill -x mihomo` 会把主实例一起带走**（主机代理直接断），永远别用名字匹配杀交叉实例。
- 验证进度用 controller API 而不只看日志：`curl 'http://127.0.0.1:19090/proxies/<name>/delay?url=http://www.gstatic.com/generate_204&timeout=10000'`，切节点 `PUT /proxies/<group> {"name":"<node>"}`。

### 12.4 delay 探测成功 ≠ 节点可用（地理白名单，最常见的假信号）

面向国内用户的机场，CDN 前端**只接受国内来源**。从海外出口测：

```
mihomo delay API  → {"delay": 133}            ← TCP 层通，看起来是好节点
实际 curl 走代理   → 000 / 0.068s / exit 35    ← TLS 握手就被对端丢掉
```

**`0.06~0.07s` 就失败 = 对端主动断连**（超时会是几秒）。看到这个组合不要再换 cipher / 换密码 / 加插件，是出口 IP 地理不对。

结论写法：**「节点结构完整、凭据已确认，需国内出口才能验活」**，不要写成「节点不可用」——你验不了不等于它是死的。派人验只能挂国内机器，或者让用户在他自己网络里试。

### 12.5 交付形态：主节点 + relay 两份清单，密码全节点通用

```python
ui = base64.b64encode(f'{method}:{password}'.encode()).decode().rstrip('=')
f'ss://{ui}@{n["ip"]}:{n["port"]}#{quote(n["name"])}'                      # 主节点（CDN 前端）
for r in n.get('relay', []):
    f'ss://{ui}@{r["ip"]}:{n["port"]}#{quote(n["name"] + "(" + r["name"] + ")")}'  # 国内中转
```

实测一批 21 条主节点 + 114 条 relay。**同一串密码对所有节点通用**（不是 per-node）——拿到一条就等于拿到全部，这时候别再回头猜「每节点独立密码」（§6 已证伪 uuid 派生）。

顺带：`http_path` 按 `platform` 参数变（`/api/v1/android/ping`、`/api/v1/cli/ping`、`/api/v1/windows/ping`…），`port` 不变。别人给的 port/path 和你对不上时，用你自己的 platform 参数重拉一遍 `clientnodelist_v3` 再下结论，别按旧数据改配置。
