#!/usr/bin/env bash
# decode_stacktrace.sh — symbolize a kernel oops / KASAN / syzkaller report.
#
# Usage:
#   ./scripts/decode_stacktrace.sh vmlinux /lib/modules/$(uname -r)/build < dmesg.log
#   dmesg -T | ./scripts/decode_stacktrace.sh /boot/vmlinux-$(uname -r)
#
# What it does
#   1. Passes the report through unchanged (stdout).
#   2. Prints a symbolization table on stderr for every addressable frame:
#        - bare addresses        0xffffffff81234567
#        - "func+0x1a/0x40"      resolved through nm, module-aware via [mod]
#      with file:line from DWARF (addr2line) when the build has debug info.
#   3. Delegates to <kernel-tree>/scripts/decode_stacktrace.sh when that
#      script is present — it is the authoritative implementation.
#
# Requires: bash, awk, nm, addr2line (binutils). No perl, no pip.
# Exit: 0 ok, 2 missing inputs, 3 nothing resolvable (wrong vmlinux).
set -uo pipefail

usage() { sed -n '2,19p' "$0" | sed 's/^# \{0,1\}//'; exit 2; }
[ $# -ge 1 ] || usage
VMLINUX="$1"
BUILDDIR="${2:-/lib/modules/$(uname -r)/build}"
[ -r "$VMLINUX" ] || { echo "error: cannot read vmlinux: $VMLINUX" >&2; exit 2; }
for t in nm addr2line awk; do
  command -v "$t" >/dev/null || { echo "error: $t not found (apt install binutils)" >&2; exit 2; }
done

# ---- 1. delegate to the in-tree tool when it exists -------------------------
for cand in "$BUILDDIR/scripts/decode_stacktrace.sh" "$(dirname "$(readlink -f "$VMLINUX")")/scripts/decode_stacktrace.sh"; do
  if [ -x "$cand" ]; then
    echo "# delegating to $cand" >&2
    exec "$cand" "$VMLINUX" "$BUILDDIR"
  fi
done

WORK=$(mktemp -d)
trap 'rm -rf "$WORK"' EXIT
cat >"$WORK/input"

# ---- 2. symbol table -------------------------------------------------------
nm -n --defined-only "$VMLINUX" 2>/dev/null | awk '$2 ~ /^[tTwW]$/ {print $1" "$3}' >"$WORK/syms"
if [ ! -s "$WORK/syms" ]; then
  echo "error: $VMLINUX has no symbol table (stripped?). Use /boot/vmlinux-<ver> or a -g build." >&2
  exit 3
fi
echo "# vmlinux=$VMLINUX symbols=$(wc -l <"$WORK/syms") builddir=$BUILDDIR" >&2

cat "$WORK/input"   # pass-through first: never lose the original report

# ---- 3. collect frames -----------------------------------------------------
# kernel addresses
grep -oE '0x[0-9a-f]{12,16}' "$WORK/input" | sort -u >"$WORK/addr"
# "func+0xoff/size" frames (optionally trailing [module])
grep -oE '[A-Za-z_][A-Za-z0-9_.$]*(\+0x[0-9a-f]+)?/0x[0-9a-f]+( \[[^]]+\])?' "$WORK/input" \
  | sort -u >"$WORK/frames"

module_path() { # $1 = module name
  local m="$1" f
  for f in "$BUILDDIR/$m.ko" "$BUILDDIR/$m/$m.ko" \
           "/lib/modules/$(uname -r)/kernel/$m.ko"; do
    [ -r "$f" ] && { printf '%s\n' "$f"; return 0; }
  done
  f=$(find "/lib/modules/$(uname -r)" -name "$m.ko*" -print -quit 2>/dev/null || true)
  [ -n "$f" ] && printf '%s\n' "$f"
  return 0
}

resolve_frames() {
  local line func off mod enc addr ko
  while IFS= read -r line; do
    [ -n "$line" ] || continue
    func=${line%%+*}
    func=${func%%/*}
    mod=""
    [[ "$line" =~ \[([^]]+)\]$ ]] && mod="${BASH_REMATCH[1]}"
    off="0"
    [[ "$line" =~ \+0x([0-9a-f]+)/ ]] && off="${BASH_REMATCH[1]}"

    if [ -n "$mod" ]; then
      ko=$(module_path "$mod")
      if [ -z "$ko" ]; then
        printf '   ? %-40s module not found on this host\n' "$line"
        continue
      fi
      enc="module:$ko"
    else
      ko="$VMLINUX"
      enc="kernel"
    fi

    local base
    base=$(nm --defined-only -n "$ko" 2>/dev/null | awk -v f="$func" '$2 ~ /^[tTwW]$/ && $3==f {print $1; exit}')
    if [ -z "$base" ]; then
      printf '   ? %-40s symbol %s not in %s\n' "$line" "$func" "$(basename "$ko")"
      continue
    fi
    addr=$(printf '0x%x' $(( 0x$base + 0x$off )))
    local loc
    loc=$(addr2line -f -C -i -e "$ko" "$addr" 2>/dev/null | paste -sd' ' -)
    printf '   %-40s %s  %s\n' "$line" "$addr" "${loc:-<no DWARF>}"
  done <"$WORK/frames"
}

echo "" >&2
echo "# frames (func+off -> address -> file:line)" >&2
if [ -s "$WORK/frames" ]; then resolve_frames; fi

if [ -s "$WORK/addr" ]; then
  echo "" >&2
  echo "# bare addresses (vmlinux)" >&2
  while IFS= read -r a; do
    loc=$(addr2line -f -C -i -e "$VMLINUX" "$a" 2>/dev/null | paste -sd' ' -)
    printf '   %-20s %s\n' "$a" "${loc:-<unresolved / not in this vmlinux>}"
  done <"$WORK/addr"
fi

NF=$(wc -l <"$WORK/frames"); NA=$(wc -l <"$WORK/addr")
echo "" >&2
echo "# done: $NF frames, $NA addresses" >&2
[ $((NF + NA)) -gt 0 ] || { echo "error: no frames or addresses found in input" >&2; exit 3; }
