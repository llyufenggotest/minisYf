---
name: ops-proxyns
description: 中文触发：代理防泄漏、出口IP泄露、mihomo TUN ｜ Kernel-level proxy protection
  (proxy-ns / mihomo TUN) — forces ALL traffic (TCP/UDP/DNS) through the proxy so
  Go/Rust/static binaries and nmap can't leak your source IP. Includes the only
  reliable leak test (`curl --noproxy '*'`), DIRECT-rule audit, multi-instance and
  persistence checks. Use BEFORE any probe that could expose your IP.
version: 1.1.0
revision_date: 2026-07-25
license: MIT
category: redteam
tags:
  - ops
  - proxyns
  - redteam
  - infrastructure
---

# OPS-PROXYNS — Kernel-Level Proxy / OPSEC Protection

## mihomo TUN — 常驻扫描节点用这个

proxy-ns 每条命令都要 `sudo proxy-ns <cmd>` 包一层，命令一多必漏。长期跑扫描的机器改用 mihomo（Clash.Meta）TUN：内核路由接管，nmap / hydra / 自己写的 python 自动全走，不用包。

但**现成配置几乎一定会漏 IP**，四处必查。

### 1. TUN 真开了吗

```yaml
tun:
  enable: true              # false → 只有显式 -x 的请求走代理，其余全裸连
  stack: system
  auto-route: true          # false → 不接管默认路由，等于没开
  auto-detect-interface: true
```

```bash
ip route get 1.1.1.1        # 必须出现 dev Meta（或 tun0）
                            # 出现 dev eth0/ens5 = 没接管，所有直连暴露本机 IP
ip route show table 2022    # mihomo auto-route 建的表，default via 198.18.0.2 dev Meta
```

### 2. 唯一可信的裸连测试

```bash
curl -s --noproxy '*' https://api.ipify.org
```

`curl -x http://127.0.0.1:7890` 永远返回节点 IP，证明不了任何事——它只证明代理可用，不证明其他流量也走代理。只有 `--noproxy '*'`（完全不带代理参数）返回的才是目标侧真正会看到的出口。改了配置后**每台机都要跑这一条**，返回本机公网 IP = 没兜住。

### 3. 规则表里的隐形泄露

现成规则集常带这两条，命中就直连：

```yaml
- GEOIP,CN,DIRECT          # 打国内目标 → 真实 IP 出去
- DST-PORT,4443,DIRECT     # 4443 直连（v2board/Xboard 面板常用端口）
```

```bash
curl -s http://127.0.0.1:9090/rules | python3 -c "
import json,sys
for r in json.load(sys.stdin)['rules']:
    if r['proxy']=='DIRECT': print(r['type'], r['payload'])"
```

只留 DNS(53/5335) / LAN / 国内镜像白名单，兜底 `MATCH,<节点>`。删掉上面两条后补镜像白名单，否则 apt/pip 绕地球：

```yaml
- DOMAIN-SUFFIX,aliyun.com,DIRECT
- DOMAIN-SUFFIX,tuna.tsinghua.edu.cn,DIRECT
- DOMAIN-SUFFIX,ustc.edu.cn,DIRECT
```

### 4. 一台机器可能跑着多个 mihomo

```bash
systemctl list-units --type=service --state=running | grep -i mihomo
```

主实例（7890）和 scan 实例（如 17890）各有独立 `config.yaml`，**规则要分别改**。只改主实例、用 scan 端口跑的扫描照样裸连。实例配置里 `tun.enable` 出现两次（重复 YAML 键）时按实际网卡判断，别信字面值。

### 5. 持久化

```bash
systemctl is-enabled mihomo          # enabled = 机器重启也生效
systemctl show mihomo -p Restart     # Restart=always = 进程挂了自动拉起
```

改完必须 `systemctl restart mihomo` 再跑一遍 `--noproxy '*'`，确认 TUN 重建、规则仍生效。只 reload 不 restart 时 TUN 不一定重建。

**残留窗口**：mihomo 崩溃到被拉起那 1-3 秒，Meta 网卡消失、默认路由回落主表，期间发起的连接会裸连。彻底堵死要在 OUTPUT 链按 cgroup/owner 放行 mihomo 自身流量、其余 REJECT（fail-closed，代价是 mihomo 挂了整机断网）。这个取舍要报给用户定，不要默认加。

---

## Why proxy-ns Over proxychains

| Feature | proxychains | proxy-ns |
|---------|-------------|----------|
| Covers Go/Rust static binaries | NO (LD_PRELOAD fails) | YES (kernel namespace) |
| DNS leak protection | Partial | Complete |
| UDP isolation | NO | YES |
| Bypassable by app | YES (direct socket) | NO |
| IPv6 leak | Common | Blocked |
| All traffic types | TCP only | TCP+UDP+DNS+ICMP |

proxy-ns uses Linux **network namespaces** to route ALL traffic from a process through a Tor proxy. The application has no way to detect or bypass it — it sees only the Tor exit node's IP.

---

## Installation

```bash
# Prerequisites
sudo apt update && sudo apt install -y tor proxychains4 git make gcc curl

# Clone and build proxy-ns
git clone https://github.com/OkamiW/proxy-ns.git /tmp/proxy-ns
cd /tmp/proxy-ns
CGO_ENABLED=0 make
sudo cp proxy-ns /usr/local/bin/

# Configure Tor
sudo tee /etc/tor/torrc << 'EOF'
SOCKSPort 9050
ControlPort 9051
CookieAuthentication 0
DataDirectory /var/lib/tor
EOF

# Restart Tor
sudo systemctl restart tor 2>/dev/null || sudo tor &
sleep 3
```

---

## Basic Usage

```bash
# Run a single command through Tor
sudo proxy-ns curl --max-time 30 --connect-timeout 10 -s ifconfig.me
# Output: [Tor exit node IP]

# Run a full shell through Tor (ALL commands go through Tor)
sudo proxy-ns $SHELL

# Inside the proxy-ns shell:
curl --max-time 30 --connect-timeout 10 -s ifconfig.me   # Tor IP
nmap -sT target.com   # Works (Go binary)
masscan 10.0.0.0/24 -p80 --rate 100  # Works
python3 -c "import requests; print(requests.get('https://ifconfig.me').text)"  # Works
whois target.com      # Works (DNS queries also routed through Tor)
```

---

## Tor Circuit Rotation

```bash
# Rotate to a new exit node IP
echo -e "AUTHENTICATE\r\nSIGNAL NEWNYM\r" | nc -w1 127.0.0.1 9051
sleep 2

# Verify new IP
sudo proxy-ns curl --max-time 30 --connect-timeout 10 -s ifconfig.me
```

### Automated Rotation Script
```bash
#!/bin/bash
# rotate-tor.sh — Rotate Tor circuit and wait for new IP
rotate() {
    echo -e "AUTHENTICATE\r\nSIGNAL NEWNYM\r" | nc -w1 127.0.0.1 9051
    sleep $(awk -v min=3 -v max=8 'BEGIN{srand(); print int(min+rand()*(max-min+1))}')
}
NEW_IP=$(sudo proxy-ns curl --max-time 30 --connect-timeout 10 -s ifconfig.me 2>/dev/null)
echo "[+] New Tor IP: $NEW_IP"

# Usage: rotate between every N requests
```

---

## IPv6 Leak Prevention

proxy-ns automatically blocks IPv6. Verify:

```bash
# Inside proxy-ns shell, test for leaks:
sudo proxy-ns bash -c '
  echo "=== IPv4 check ==="
  curl --max-time 30 --connect-timeout 10 -s ifconfig.me
  echo ""
  echo "=== IPv6 check (should fail) ==="
  curl --max-time 30 --connect-timeout 10 -6 -s ifconfig.me 2>&1 || echo "[OK] No IPv6"
  echo "=== DNS leak check ==="
  dig +short myip.opendns.com @resolver1.opendns.com
'
```

---

## Stealth Headers and Jitter

Always use rotating User-Agent and jitter between requests:

```python
# stealth_headers.py — Use inside proxy-ns shell
import requests, random, time

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/[REDACTED_IP]",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64; rv:121.0) Gecko/20100101 Firefox/121.0",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15",
]

ACCEPT_LANGS = ["en-US,en;q=0.9", "en-GB,en;q=0.8", "en-CA,en;q=0.7"]

def stealth_session():
    s = requests.Session()
    s.headers.update({
        "User-Agent": random.choice(USER_AGENTS),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": random.choice(ACCEPT_LANGS),
        "Accept-Encoding": "gzip, deflate",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1",
    })
    return s

def stealth_get(url, session=None, min_delay=2, max_delay=6):
    """Make a stealth GET with jitter"""
    s = session or stealth_session()
    time.sleep(random.uniform(min_delay, max_delay))
    return s.get(url, timeout=30)

# Usage:
# session = stealth_session()
# r = stealth_get("https://target.com/.env", session=session)
```

---

## Real Exposure Risks

| Risk | How It Happens | Consequence |
|------|---------------|-------------|
| **Leaked IP** | Server logs, WebRTC, DNS leaks | Blocking, tracking |
| **Fingerprinting** | User-Agent, TLS fingerprint (JA3), headers | Identified as bot |
| **Rate Limit** | Too many requests in a short period | IP permanently blocked |
| **Honeypot** | Fake endpoint that alerts the security team | Legal action |
| **SIEM/Splunk** | Centralized logs detect patterns | Security team alerted |
| **Cloudflare WAF** | Many sequential 403/503 | IP added to blacklist |
| **Tracked SA Key** | Excessive service account usage | Key revoked |
| **GitHub API** | Too many queries on the search API | Rate limit, token revoked |

## Pre-Test OPSEC Checklist

Before making ANY request to a target:

```
[ ] VPN/Tor active and verified (ifconfig.me shows non-originating IP)
[ ] IP not leaking? (check https://ipleak.net)
[ ] DNS not leaking (dig myip.opendns.com @resolver1.opendns.com)
[ ] WebRTC disabled?
[ ] IPv6 disabled/blocked (curl -6 ifconfig.me should fail)
[ ] Generic and rotating User-Agent?
[ ] Random delay (2-6s jitter between requests)?
[ ] GitHub credentials NOT logged in (or use dedicated burner account)
[ ] Nmap using -sT (SYN scan -sS is unsupported via proxy)
[ ] proxy-ns shell active for ALL commands (not just curl)
[ ] GitHub credentials logged in only when needed?
```

---

## Rate Limiting Protection

```bash
# Rotate IP between every N requests automatically
for i in $(seq 1 10); do
  echo "Request $i"
  sudo proxy-ns curl --max-time 30 --connect-timeout 10 -s "https://target.com/.env" > /dev/null
  sleep 3
done

# After 10 requests, rotate Tor circuit
echo -e "AUTHENTICATE\r\nSIGNAL NEWNYM\r" | nc -w1 127.0.0.1 9051
sleep 3
NEW_IP=$(sudo proxy-ns curl --max-time 30 --connect-timeout 10 -s ifconfig.me)
echo "[+] Rotated to IP: $NEW_IP"
```

---

## Recon Under proxy-ns

Run the entire recon toolchain inside proxy-ns:

```bash
# Start proxy-ns shell
sudo proxy-ns $SHELL

# Inside the protected shell:
TARGET="target.com"

# subfinder works (Go binary)
subfinder -d "$TARGET" -silent > subs.txt

# httpx works
cat subs.txt | httpx -silent -status-code > live.txt

# curl works
curl --max-time 30 --connect-timeout 10 -sk "https://$TARGET/.env" | grep -i "DB_PASSWORD"

# nuclei works
nuclei -l live.txt -t ~/nuclei-templates/ -severity critical,high

# Python requests work
python3 -c "
import requests
r = requests.get('https://target.com/wp-json/wp/v2/users')
print(r.status_code, len(r.text))
"
```

---

## Common Pitfalls

| Issue | Solution |
|-------|----------|
| `sudo: proxy-ns: command not found` | Rebuild: `cd /tmp/proxy-ns && sudo make install` |
| Tor not running | `sudo systemctl start tor` or `sudo tor &` |
| `Connection refused` on port 9050 | Check `sudo netstat -tlnp | grep 9050` |
| Nmap SYN scan fails | Use `nmap -sT` (TCP connect scan) instead of `-sS` |
| Masscan banner grabbing | Use `--source-ip` with an interface IP on the host |
| Go binaries still show real IP | Ensure proxy-ns is installed correctly: `CGO_ENABLED=0 make` |
| Too slow (Tor latency) | Tor is naturally slow. Increase jitter or use a premium VPN as alternative. |

---

## Alternatives

If proxy-ns doesn't work on your kernel:

```bash
# Level 1: proxychains (works for Python/curl, NOT for Go/static binaries)
sudo apt install proxychains4
proxychains4 curl ifconfig.me

# Level 2: Full VPN (best performance, worst OPSEC — VPN logs)
# Level 3: Tails OS / Whonix (entire OS is Tor-routed)
# Level 4: Dedicated pentest VPS (separate jurisdiction)
```

---

## Verification

1. **Proxy test** — confirm proxy connectivity:
   ```bash
   curl --max-time 30 --connect-timeout 10 -s --proxy "http://127.0.0.1:8080" "https://httpbin.org/ip" 2>/dev/null | python3 -m json.tool 2>/dev/null || echo "NOTE: no proxy configured locally"
   ```
2. **DNS leak test** — verify DNS resolution path:
   ```bash
   dig +short example.com 2>/dev/null | head -1 && echo "PASS: DNS resolution works" || echo "FAIL: dig not available"
   ```
All tests verify proxy readiness.

---

## Pitfalls
- **Proxy not rotating** — if the same IP is used for all requests, rate limiting and IP bans are inevitable. Verify rotation is actually working.
- **Proxy logs containing credentials** — HTTP proxies log full request URLs. Ensure proxy logs are sanitized before sharing.
- **DNS leaks through proxy** — some proxy configurations leak DNS. Test with `dnsleaktest.com`-equivalent before running sensitive operations.
- **Proxy chain latency** — multi-hop proxy chains add latency that breaks timing-based attacks. Test throughput before running time-sensitive probes.
- **SOCKS vs HTTP proxy confusion** — SOCKS5 proxies tunnel TCP; HTTP proxies only tunnel HTTP. Use the right proxy for the protocol.

