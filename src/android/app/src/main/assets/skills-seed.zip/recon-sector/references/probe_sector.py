#!/usr/bin/env python3
"""probe_sector.py — sector-aware HTTP probe for a target list.

Reads the sector definition from references/sectors.yaml, probes each
target for that sector's high_value_paths, and writes:

  outdir/probe_<sector>.jsonl     one line per (target, path) with status/size/type
  outdir/probe_<sector>.csv       compact: target,path,status,bytes,ct,note
  outdir/summary_<sector>.json    per-status counts + per-target hit counts

Usage:
  python3 references/probe_sector.py <sector> <targets.txt> <outdir> \
      [--proxy http://127.0.0.1:8080] [--threads 8] [--timeout 10] \
      [--rate 5] [--user-agent ...] [--insecure]

Design notes (why it looks like this):
- stdlib only: runs on a box with no pip access.
- honors HTTPS_PROXY/ALL_PROXY when --proxy is not given, so it stays inside
  the authorised egress path.
- HEAD first, GET only when HEAD is 405/501 or --get; a 200 with a 0-byte
  body is reported as such instead of being counted as a hit.
- never follows redirects cross-host (an off-scope redirect is not a finding).
- a transport error is `err`, never `404`: "not found here" != "dead".
"""
import argparse
import json
import os
import ssl
import sys
import threading
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed

INTERESTING = {200: "open", 401: "auth", 403: "forbidden", 301: "redir", 302: "redir", 500: "error"}


def load_sector(path, sector):
    """Tiny YAML subset parser: enough for references/sectors.yaml."""
    try:
        import yaml  # noqa: F401
        with open(path, encoding="utf-8") as f:
            doc = yaml.safe_load(f) or {}
        sec = (doc.get("sectors") or {}).get(sector)
        if not sec:
            raise KeyError(sector)
        return {
            "platforms": sec.get("platforms", []),
            "cms": sec.get("cms_dominant", ""),
            "paths": sec.get("high_value_paths", []),
            "pii_risk": sec.get("pii_risk", ""),
        }
    except ImportError:
        pass
    # fallback: indentation-aware scan, no PyYAML
    cur = None
    depth = {}
    out = {"platforms": [], "cms": "", "paths": [], "pii_risk": ""}
    with open(path, encoding="utf-8") as f:
        for raw in f:
            line = raw.rstrip("\n")
            if not line.strip() or line.lstrip().startswith("#"):
                continue
            ind = len(line) - len(line.lstrip())
            key = line.strip().split(":", 1)[0]
            if ind == 2:
                cur = key
            elif cur == sector:
                if line.strip().startswith("- ") and ind >= 6:
                    out["paths"].append(line.strip()[2:].strip().strip('"'))
                elif line.strip().startswith("cms_dominant:"):
                    out["cms"] = line.split(":", 1)[1].strip().strip('"')
                elif line.strip().startswith("platforms:"):
                    raw_v = line.split(":", 1)[1].strip()
                    if raw_v:
                        out["platforms"] = [x.strip() for x in raw_v.strip("[]").split(",") if x.strip()]
                elif line.strip().startswith("pii_risk:"):
                    out["pii_risk"] = line.split(":", 1)[1].strip().strip('"')
    if not out["paths"]:
        raise KeyError(f"sector '{sector}' has no high_value_paths in {path}")
    return out


def build_opener(proxy, insecure, ua):
    ctx = ssl.create_default_context()
    if insecure:
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    handlers: list = [urllib.request.HTTPSHandler(context=ctx)]
    proxy = proxy or os.environ.get("HTTPS_PROXY") or os.environ.get("https_proxy") \
        or os.environ.get("ALL_PROXY") or os.environ.get("all_proxy")
    if proxy:
        handlers.append(urllib.request.ProxyHandler({"http": proxy, "https": proxy}))
    else:
        handlers.append(urllib.request.ProxyHandler({}))
    opener = urllib.request.build_opener(*handlers)
    opener.addheaders = [("User-Agent", ua), ("Accept", "*/*"), ("Accept-Encoding", "identity")]
    return opener


class Rate:
    def __init__(self, per_sec):
        self.interval = 1.0 / per_sec if per_sec > 0 else 0
        self.lock = threading.Lock()
        self.next = 0.0

    def wait(self):
        if not self.interval:
            return
        with self.lock:
            now = time.monotonic()
            if self.next > now:
                time.sleep(self.next - now)
            self.next = max(now, self.next) + self.interval


def probe(opener, rate, url, method, timeout):
    rate.wait()
    req = urllib.request.Request(url, method=method)
    t0 = time.time()
    try:
        with opener.open(req, timeout=timeout) as r:
            body = b"" if method == "HEAD" else r.read(2048)
            return {
                "url": url, "method": method, "status": r.status,
                "bytes": r.headers.get("Content-Length") or len(body),
                "ct": (r.headers.get("Content-Type") or "").split(";")[0],
                "final": r.geturl(), "secs": round(time.time() - t0, 3), "err": "",
            }
    except urllib.error.HTTPError as e:
        return {"url": url, "method": method, "status": e.code, "bytes": 0,
                "ct": (e.headers.get("Content-Type") or "").split(";")[0] if e.headers else "",
                "final": url, "secs": round(time.time() - t0, 3), "err": ""}
    except Exception as e:  # DNS/TLS/timeout/proxy — never silently a 404
        return {"url": url, "method": method, "status": 0, "bytes": 0, "ct": "",
                "final": url, "secs": round(time.time() - t0, 3), "err": f"{type(e).__name__}: {e}"[:200]}


def norm_target(t):
    """Return (host, scheme, explicit) — scheme is detected later when absent."""
    t = t.strip()
    if not t or t.startswith("#"):
        return None
    explicit = True
    if t.startswith(("http://", "https://")):
        scheme, rest = t.split("://", 1)
    else:
        explicit, scheme, rest = False, "https", t
    return rest.rstrip("/"), scheme, explicit


def detect_scheme(opener, rate, host, timeout):
    """Sites that talk plain HTTP are common; never report them all as 'err'."""
    for sch in ("https", "http"):
        try:
            rate.wait()
            req = urllib.request.Request(f"{sch}://{host}/", method="HEAD")
            with opener.open(req, timeout=timeout) as r:
                r.read(0)
                return sch
        except urllib.error.HTTPError:
            return sch          # TLS/HTTP layer answered: scheme is right
        except Exception:
            continue
    return "http"


def note_of(row):
    st = row["status"]
    if row["err"]:
        return "err"
    if st in (401, 403):
        return INTERESTING[st]
    if st == 200:
        try:
            n = int(row["bytes"] or 0)
        except (TypeError, ValueError):
            n = 0
        return "open+body" if n > 0 else "open-empty"
    if st in INTERESTING:
        return INTERESTING[st]
    return "other"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("sector")
    ap.add_argument("targets")
    ap.add_argument("outdir")
    ap.add_argument("--sectors", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "sectors.yaml"))
    ap.add_argument("--proxy", default="")
    ap.add_argument("--threads", type=int, default=8)
    ap.add_argument("--timeout", type=float, default=10)
    ap.add_argument("--rate", type=float, default=5.0, help="requests per second (0 = unlimited)")
    ap.add_argument("--user-agent", default="Mozilla/5.0 (X11; Linux x86_64) probe_sector/1")
    ap.add_argument("--get", action="store_true", help="force GET for every path")
    ap.add_argument("--insecure", action="store_true")
    a = ap.parse_args()

    try:
        sec = load_sector(a.sectors, a.sector)
    except KeyError as e:
        sys.stderr.write(f"error: {e}\n")
        avail = sorted(k for k in _sector_names(a.sectors))
        sys.stderr.write("available sectors: " + ", ".join(avail) + "\n")
        return 2
    except OSError as e:
        sys.stderr.write(f"error: cannot read {a.sectors}: {e}\n")
        return 2

    targets = []
    with open(a.targets, encoding="utf-8") as f:
        for raw in f:
            t = norm_target(raw)
            if t:
                targets.append(t)
    opener = build_opener(a.proxy, a.insecure, a.user_agent)
    rate = Rate(a.rate)

    bases = []
    for host, scheme, explicit in targets:
        if not explicit:
            scheme = detect_scheme(opener, rate, host, a.timeout)
        bases.append((host, f"{scheme}://{host}"))
        print(f"target {host} -> {scheme}")

    jobs = []
    for host, base in bases:
        for p in sec["paths"]:
            url = base + "/" + p.lstrip("/")
            jobs.append((host, p, url, "GET" if a.get else "HEAD"))

    print(f"sector={a.sector} targets={len(targets)} paths={len(sec['paths'])} requests={len(jobs)}")
    if sec["cms"]:
        print(f"dominant CMS={sec['cms']} platforms={','.join(sec['platforms'])}")
    jl = os.path.join(a.outdir, f"probe_{a.sector}.jsonl")
    rows = []
    with open(jl, "w", encoding="utf-8") as out, ThreadPoolExecutor(max_workers=a.threads) as ex:
        futs = {ex.submit(probe, opener, rate, u, m, a.timeout): (h, p) for h, p, u, m in jobs}
        for i, fu in enumerate(as_completed(futs), 1):
            row = fu.result()
            row["host"], row["path"] = futs[fu]
            row["note"] = note_of(row)
            rows.append(row)
            out.write(json.dumps(row, ensure_ascii=False) + "\n")
            if i % 25 == 0:
                print(f"  {i}/{len(jobs)}", file=sys.stderr)

    csv_path = os.path.join(a.outdir, f"probe_{a.sector}.csv")
    with open(csv_path, "w", encoding="utf-8") as f:
        f.write("host,path,method,status,bytes,ct,note,final\n")
        for r in rows:
            f.write(",".join([
                r["host"], r["path"], r["method"], str(r["status"]), str(r["bytes"]),
                r["ct"] or "-", r["note"], r["final"],
            ]).replace(",", ";") + "\n")

    summary = {"sector": a.sector,
               "targets": [f"{b}" for _, b in bases], "requests": len(rows),
               "by_note": {}, "hits": {}}
    for r in rows:
        summary["by_note"][r["note"]] = summary["by_note"].get(r["note"], 0) + 1
        if r["note"] in ("open+body", "auth", "forbidden"):
            summary["hits"].setdefault(r["host"], []).append(r["path"])
    sp = os.path.join(a.outdir, f"summary_{a.sector}.json")
    with open(sp, "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=1)

    print(f"\nnotes: {summary['by_note']}")
    print(f"hosts with hits: {len(summary['hits'])}")
    print(f"wrote {jl}\n      {csv_path}\n      {sp}")
    return 0


def _sector_names(path):
    try:
        with open(path, encoding="utf-8") as f:
            for line in f:
                if line.startswith("  ") and line.rstrip().endswith(":") and not line.startswith("   "):
                    yield line.strip().rstrip(":")
    except OSError:
        return


if __name__ == "__main__":
    sys.exit(main())
