---
name: origin-ip-discovery
description: "中文触发：找源站 IP、绕 CDN、查真实 IP（favicon/DNS/Cert）"
version: 1.1.0
revision_date: 2026-07-25
license: MIT
platforms:
  - linux
compatibility: Requires curl, dnsx, python3, subfinder
tags:
  - recon
  - origin-ip
  - CDN
  - WAF
  - bypass
  - Cloudflare
  - favicon
  - DNS
category: recon
related_skills:
  - subdomain-enumeration
  - vhost-enumeration
  - port-mass-scan
---

# Origin IP Discovery

Discover the real server IP behind CDN/WAF protections (Cloudflare, Akamai, Fastly). When the origin IP is found, the raw server is exposed without firewall rules, rate limiting, or application-layer filtering. Techniques include favicon hash fingerprinting across Shodan, historical DNS records from passive sources, SSL certificate SAN field matching, and Google Analytics ID cross-referencing.

## When to Use

- Target is behind Cloudflare/Akamai and returns 403 or CAPTCHA challenges on all requests.
- You need direct access to the origin to bypass WAF rules.
- Subdomain enumeration reveals internal/staging hosts on non-CDN IPs.
- The target uses a single favicon across all infrastructure.
- SSL certificates share the same organization name across IPs.

## Prerequisites

- `terminal` with curl, python3, and shodan CLI.
- Shodan API key: `shodan init <KEY>`.
- Target favicon file or URL.

## Quick Detection

```bash
# Check Cloudflare presence
curl --max-time 30 --connect-timeout 10 -sI "https://target.com" | grep -i "cf-ray\|server: cloudflare"

# If Cloudflare detected, check for common origin leaks
curl --max-time 30 --connect-timeout 10 -sk "https://target.com/cdn-cgi/trace" | grep -E "ip=|colo="
```

## Procedure

### Phase 0 — 先判断这个主机到底有没有源站（跳过就白跑一整轮）

不是所有「CF 前置」后面都有一台服务器。**没有源站的资产，Phase 1-6 全部无效**，先花 30 秒判掉：

```bash
curl -s -m 15 https://assets.target.com/ | grep -oiE "cloudflare.com/favicon|Not Found" | head -2
curl -s -m 15 -o /dev/null -w '%{http_code}\n' https://assets.target.com/_headers
```

| 现象 | 结论 | 该怎么办 |
|---|---|---|
| 404 页里有 `https://www.cloudflare.com/favicon.ico` + 默认 "Not Found" 模板 | **Cloudflare Pages**（纯静态托管） | 没有源站，别找了。改它只能靠 CF 部署凭据或关联的 Git 仓库 |
| `/?list-type=2` / `/?prefix=` 返 XML 或 `AccessDenied` | **R2 / S3 对象存储** | 同上，无源站；只能靠桶凭据或某个上传接口覆盖对象键 |
| `cf-cache-status: DYNAMIC` 但首页是正常业务 | 有源站 | 继续 Phase 1-6 |

这一判定直接决定结论口径：assets 打不到源站，就意味着依赖它分发的客户端更新链（install.sh / 二进制）**只能靠 MITM 利用**，报告里不能把客户端侧供应链洞写成「无需中间人的服务端 RCE」。

### Phase 1 — Favicon Hash Fingerprinting

```bash
# Get favicon hash
FAVICON_URL="https://target.com/favicon.ico"
curl --max-time 30 --connect-timeout 10 -sk "$FAVICON_URL" -o favicon_target.ico

# Calculate hash
python3 -c "
import hashlib, base64
with open('favicon_target.ico', 'rb') as f:
    hash_bytes = base64.b64encode(hashlib.md5(f.read()).digest())
    print(f'favicon hash: {hash_bytes.decode()}')
"

# Search Shodan for IPs serving this favicon
HASH=$(python3 -c "
import hashlib, base64
with open('favicon_target.ico','rb') as f:
    print(base64.b64encode(hashlib.md5(f.read()).digest()).decode())
")
shodan search "http.favicon.hash:$HASH" --fields ip_str,port,org,hostnames

# Automatedtools
python3 favUp.py -ff favicon_target.ico --shodan-cli
python3 favUp.py --web target.com -sc
```

### Phase 2 — Historical DNS Records

```bash
# SecurityTrails — DNS history
curl --max-time 30 --connect-timeout 10 -s "https://securitytrails.com/domain/target.com/history/a" \
  -H "APIKEY: $SECURITYTRAILS_KEY" \
  | jq '.records[].values[].ip' | sort -u

# AlienVault OTX — passive DNS
curl --max-time 30 --connect-timeout 10 -s "https://otx.alienvault.com/api/v1/indicators/domain/target.com/passive_dns" \
  | jq '.passive_dns[].address' | sort -u

# hackertarget hostsearch — 无 key，crt.sh 挂掉时最顶用的一个（实测靠它拿到全场唯一裸 IP）
curl --max-time 20 -s "https://api.hackertarget.com/hostsearch/?q=target.com"
#   → area0.target.com,166.88.141.128   逗号分隔，一眼看出哪个不在 CF 段
#   免费额度约 50 次/天，超了返 "API count exceeded"；按域名查，别循环几百个子域

# certspotter — 证书 SAN，无 key
curl --max-time 20 -s "https://api.certspotter.com/v1/issuances?domain=target.com&include_subdomains=true&expand=dns_names" \
  | jq -r '.[].dns_names[]' | sort -u

# Automatedtools
echo "target.com" | originiphunter
cat domains.txt | originiphunter
```

### Phase 3 — SSL Certificate Search

```bash
# crt.sh — find all certs for the domain, extract unique IPs from SAN fields
curl --max-time 30 --connect-timeout 10 -s "https://crt.sh/?q=%25.target.com&output=json" \
  | jq -r '.[].name_value' | tr ',' '\n' | sort -u > cert_domains.txt

# Censys — search by parsed names
# Web: https://search.censys.io — query: parsed.names: target.com

# Shodan — search by SSL subject CN
shodan search "ssl.cert.subject.cn:target.com" --fields ip_str,port,org

# Netlas — deep infrastructure search
# Web: https://netlas.io — query: domain:*.target.com
```

### Phase 4 — Google Analytics ID Cross-Referencing

```bash
# Extract Analytics ID from target pages
curl --max-time 30 --connect-timeout 10 -s "https://target.com" | grep -Eo '(?:UA-|G-|GTM-)[A-Z0-9]+'

# Find all domains sharing the same GA ID
curl --max-time 30 --connect-timeout 10 -s "https://api.hackertarget.com/analyticslookup/?q=UA-XXXXXXXX-X"
curl --max-time 30 --connect-timeout 10 -s "https://builtwith.com/relationships/target.com"

# Automated
cat subdomains.txt | analyticsrelationships
```

### Phase 5 — Common Origin Leak Vectors

```bash
# Direct IP in page source
curl --max-time 30 --connect-timeout 10 -sk "https://target.com" | grep -Eo '\b(?:\d{1,3}\.){3}\d{1,3}\b' | sort -u

# DNS CNAME chain — may expose origin
dig target.com ANY +noall +answer
dig www.target.com CNAME +short

# MX records — mail server often shares infrastructure
dig target.com MX +short

# SPF records — may contain non-CDN IPs
dig target.com TXT +short | grep -Eo '\b(?:\d{1,3}\.){3}\d{1,3}\b'

# Subdomain with different IP pattern
subfinder -d target.com -silent | dnsx -silent -a -resp-only | sort -u > all_ips.txt
# Filter out Cloudflare IPs (104.x, 172.64-71.x)
grep -vE '^104\.(1[6-9]|2[0-9]|3[0-1])\.|^172\.(6[4-9]|7[0-1])\.' all_ips.txt > non_cf_ips.txt
# Probe each for the target's content
for ip in $(cat non_cf_ips.txt); do
  curl --max-time 30 -sk --connect-timeout 5 "https://$ip" -H "Host: target.com" -o /dev/null -w "%{http_code} $ip\n"
done | grep -v "^403\|^000"
```

### Phase 6 — Validate Origin

```bash
# Check if IP serves the target's content
curl --max-time 30 --connect-timeout 10 -sk "https://ORIGIN_IP" -H "Host: target.com" | grep -o '<title>[^<]*</title>'

# Verify favicon matches
curl --max-time 30 --connect-timeout 10 -sk "https://ORIGIN_IP/favicon.ico" -H "Host: target.com" -o favicon_origin.ico
md5sum favicon_target.ico favicon_origin.ico  # should match

# Probe ports directly on origin
naabu -host ORIGIN_IP -p - -rate 2000
```

## Pitfalls

- **Cloudflare may block your IP on repeated scans.** Rotate user-agents and proxies.
- **Shodan queries require an API key.** Free tier is rate-limited.
- **The origin may also be behind firewall rules.** Even if you find the IP, it may only accept traffic from Cloudflare's IP ranges.
- **Google Analytics IDs are shared across unrelated sites.** Verify by favicon or content match before claiming a finding.
- **Non-CDN IPs from subdomains may be load balancers,** not the actual web server origin. Probe with Host header to confirm.
- **crt.sh 会整体不可用（`HTTP=000`、空 body），不等于没子域。** 换 hackertarget hostsearch 或 certspotter 重跑一次再下结论。
- **历史 DNS 捡到的裸 IP 可能只是节点/跳板机**：只开 22、业务端口全关，就不是 Web 源站，别在这台上耗口令。

## Verification

1. Favicon hash matches between CDN-cached site and direct origin IP.
2. HTTPS request to origin IP with `Host: target.com` returns the same page content.
3. Open ports on origin differ from CDN-proxied ports (origin exposes SSH, MySQL, etc.).
4. SSL certificate on the origin IP lists the target domain in SAN.

## Related Skills

- **`subdomain-enumeration`** — Generate the subdomain list needed for IP deduplication.
- **`vhost-enumeration`** — Once origin IP is found, enumerate virtual hosts.
- **`port-mass-scan`** — Scan origin IP for exposed services.
