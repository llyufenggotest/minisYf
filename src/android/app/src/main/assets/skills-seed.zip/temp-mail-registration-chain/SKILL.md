---
name: temp-mail-registration-chain
version: 1.0.0
author: 御风
license: MIT
platforms: [linux, macos, windows]
description: "Use when 批量注册/落号需要邮箱验证码（moakt/mail.tm 临时邮箱收码链）。"
metadata:
  hermes:
    tags: [registration, temp-mail, moakt, verification-code, account-harvest]
    related_skills: [seagull-pentest, proxy-subscription-harvesting]
---

# 临时邮箱批量注册收割链

目标：对「注册/登录需邮箱验证码」的目标站点全自动落号。交付物是可复用的收码链（建箱 → 触发发码 → 收码 → 注册），不是一次性账号。

## When to Use

- 目标注册要邮箱验证码：`register {email, code}`、`login/code {email, code}`、`forgot-password/complete {email, code}`
- 需要批量落号：新用户赠金、邀请返利、薅 AI 调用额度

## 铁律

- **触发发码后必须立即收、立即用**。连续发信会覆盖旧码（服务端回「验证码已失效」），码有效期约 10 分钟但从邮件到达起算——囤码必烂。
- **邮箱用户名必须唯一**。moakt 同用户名的箱子可能是别人用过的，历史邮件（别的产品的验证码）会混进收件箱造成误读。
- **验证码格式别用数字正则硬抓**。实测同时存在 6 位纯数字和 6 位 hex（如 `94ebfb`）——数字正则对 hex 码永远零命中，必须用 `[0-9a-f]{6}` 或邮件正文锚文本。
- 收码链要先在自己邮箱上跑通全流程（建箱→发码→收→注册成功），再去打目标。
- **先探域名黑名单，再建箱**。README 写着「需邮箱验证」的站，很可能内建一份一次性域名黑名单，且检查排在验证码校验**之前**——不先探就会拿着 moakt 地址把整条链跑完才发现第一步就死。

## 目标端一次性邮箱黑名单（先探再用）

不少商业站（尤其付费类）会调 `disposable-email-domains` 这类**静态域名清单**，只按 `@` 后半段精确匹配，不查 MX。实测一次性/别名类域名**全灭**：`teml.net` `moakt.cc` `moakt.co` `moakt.ws` `disbox.net` `disbox.org` `tmpmail.net` `tmpmail.org` `tmpeml.com` `tmail.ws` `bareed.ws` `tmails.net` `drmail.in` `mailinator.com` `guerrillamail.com` `sharklasers.com` `yopmail.com` `maildrop.cc` `1secmail.com/.org` `dropmail.me` `emlhub.com` `emlpro.com` `emltmp.com` `10mail.org` `emailfake.com` `tempr.email` `discard.email` `spamgourmet.com` `33mail.com` `inboxkitten.com` `mohmal.com` `getnada.com` `emailondeck.com` `throwawaymail.com` `temp-mail.org` `mail.tm(maxxspace.com)`。

放行的：`gmail.com` `outlook.com` `live.com` `qq.com` `foxmail.com` `zoho.com` `gmx.com` `mail.com` `protonmail.com` `tuta.com` `cock.li` `duck.com` `mozmail.com` `simplelogin.co` `burnermail.io`（后六个是别名/需账号类，收信要另外搭）。

**探测法（一个域名一次请求，读完前置错误即可判断）**：

```
# 每个候选域名：换一个唯一 local part，打一次发码
POST /api/register/send-email  {"email":"probe<rand>@<domain>", ...}
→ "Disposable email addresses are not allowed"  ⇒ 黑名单
→ "Code sent"                                    ⇒ 放行，可以用
```

- 逐次单独跑，别并发：发码接口普遍带按邮箱或按 IP 冷却
- 前置错误会**掩盖**真实错误，顺序是「黑名单 → Turnstile → 验证码」。看到 `Disposable email` 就不要再去调 code 校验，先换域名
- 放行名单只是**快照**，不要当存档；每次重探一遍成本很低

## 工作流（顺序固定）

1. **建箱**：browser session 里 fetch POST 建箱（保登录态跨调用）
2. **触发发码**：打目标的验证码端点（`get/email/code?email=` 或 `verification-codes/email` POST）
3. **等 ~15 秒轮询收件箱**（listmonk 发出的邮件延迟 15 秒级，15s 一轮基本一轮命中）
4. **解析验证码**：详情页正文锚文本定位，别全文正则
5. **立即注册/登录**：从拿到码到发出请求控制在 1 分钟内

## moakt.com 工作流（风哥指定主力，mail.tm 被目标屏蔽时的替代）

```python
# browser_exec 内执行
# 1) 建箱
fd = FormData(); fd.append('domain','teml.net'); fd.append('username','<唯一名>'); fd.append('setemail','<user>@teml.net')
fetch('/zh/inbox', {method:'POST', body: fd, redirect:'manual'})  # opaqueredirect = 正常
# 2) 轮询收件箱
h = (await fetch('/zh/inbox', {credentials:'include'})).text()
# DOMParser 解析 a[href*="/zh/email/"] 拿邮件 uuid
# 3) 详情页 goto_url 导航（fetch 详情页会被重定向回 inbox），innerText 找锚文本
```

- 邮件正文锚文本（AskFox/APINebula 系）：`verification code for this request is: <码>`，10 分钟有效
- **箱子 1 小时过期**——页面有倒计时；长会话任务中途要换箱
- 建箱响应是 opaqueredirect 不是 JSON，别用 json.loads 解析

## mail.tm（备选）

- API：`/domains` `/accounts` `/token` `/messages`；`/domains` 可能返回 hydra:member 分页结构（解析时兼容 list/dict）
- 实测被部分目标邮件系统屏蔽（触发 200 success 但收不到）——先 moakt 再 mail.tm

## 目标端限速模型（决定验证码爆破可不可行）

自研 Java 后端常见配置，打之前先摸清：

- **3 次错误锁当前码**（第 4 次起「验证码次数过多」→ 码作废）；也见过 **5 次变体**（`Invalid code. 4 attempts remaining` 递减到 1）。两者都意味着 6 位码（100 万）÷ 3~5 次 ≈ 20~33 万次新发信，而发码还要过 Turnstile + 冷却 → **验证码爆破不可行**
- **先发一次错码看响应里有没有 `attempts remaining`**，一条请求就能判定要不要放弃爆破，比写完脚本才发现白跑省得多
- **3 次发信限速**（每邮箱/窗口，「验证码发送过于频繁」）
- hex6 空间 = 1670 万，叠加 3+3 限速 = **验证码爆破不可行**，老老实实收码
- **登录端点常无限速**——拿到有效码登录后若要打密码爆破，走登录端点（字典×运营者邮箱）

## 坑

- 邮件详情页 fetch 会被重定向回 inbox 拿到列表页——用 `goto_url` 导航详情再读 `innerText`
- browser_exec 的 JS 里别用 `\b` 边界正则（Python→JS 传递会炸 SyntaxError），用字符类 `[0-9a-f]{6}`
- 「验证码已失效」≠ 码错——是码被后续发信覆盖或过期，重新触发一发
- 邮箱枚举侧信道：forgot-password 对有无注册账号可能同回 success，但「该收件邮箱请求过于频繁」类限速消息会暴露该邮箱有发信记录

配套：`seagull-pentest` 技能内的自研后端侦察参考（验证码端点识别与限速测试、OpenAPI schema 读法）。
